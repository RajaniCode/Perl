package NewAuthApp::Model::AuthSchema;
use strict;
use warnings;
use base 'Catalyst::Model::DBIC::Schema';
1;
