package Fu::Schema;
use strict;
use base qw/DBIx::Class::Schema/;
__PACKAGE__->load_namespaces();

1;
